const caixaPrincipal = document.querySelector(".caixa-principal");
const caixaPerguntas = document.querySelector(".caixa-perguntas");
const caixaAlternativas = document.querySelector(".caixa-alternativas");
const caixaResultado = document.querySelector(".caixa-resultado");
const textoResultado = document.querySelector(".texto-resultado");

const perguntas = [
    {
        enunciado: "E se os pilotos de corridas ilegais usassem suas habilidades em competições oficiais, eles poderiam se tornar atletas reconhecidos e até mudar de vida?",
        alternativas: [
            "Sim, poderiam se destacar legalmente no automobilismo.",
            "Não, poderiam ser presos e causar tragédias irreversíveis."
        ]
    },
    {
        enunciado: "E se uma corrida ilegal resultasse em um acidente grave envolvendo pedestres inocentes, quem assumiria a responsabilidade?",
        alternativas: [
            "Se os responsáveis assumissem a culpa, isso poderia incentivar mais cuidado e prevenir futuros acidentes.",
            "Muitas vezes, ninguém assume responsabilidade, e as vítimas ficam desamparadas."
        ]
    },
     {
        enunciado: "E se as corridas ilegais fossem legalizadas e organizadas em ambientes controlados, isso reduziria os riscos à população?",
        alternativas: [
            "Sim, com controle e segurança, os riscos diminuiriam bastante.",
            "Não, a legalização poderia incentivar mais pessoas a participar, aumentando o perigo."
        ]
    },
    {
        enunciado: "É possível ganhar dinheiro com corridas ilegais?",
        alternativas: [
            "Sim, alguns conseguem prêmios ou apostas.",
            "Não, é ilegal e pode levar a multas e prisão."
        ]
    },
    {
        enunciado: "As corridas ilegais melhoram as habilidades de direção?",
        alternativas: [
            "Sim, praticam técnicas de direção avançadas.",
            "Não, só tranforma quem prática isso em um perigo para a sociedade"
        ]
    }
];

let atual = 0;
let perguntaAtual;
let historiaFinal = "";

function mostraPergunta() {
    if (atual >= perguntas.lenght){
        mostraResultado();
        return;
    }
    perguntaAtual = perguntas[atual];
    caixaPerguntas.textContent = perguntaAtual.enunciado;
    caixaAlternativas.textContent = "";
    mostraAlternativas();
}

function mostraAlternativas(){
    for (const alternativa of perguntaAtual.alternativas){
        const botaoAlternativas = document.createElement("button");
        botaoAlternativas.textContent = alternativa;
        botaoAlternativas.addEventListener("click", () => respostaSelecionada(alternativa));
        caixaAlternativas.appendChild(botaoAlternativas);
    }
} 
mostraPergunta();

function respostaSelecionada(opcaoSelecionada){
    const afirmacoes = opcaoSelecionada.afirmacoes;
    historiaFinal = afirmacoes;
    historiaFinal  += afirmacoes + "";
    atual++;
    mostraPergunta();
}

function mostraResultado(){
    caixaPerguntas.textContent = "";
    textoResultado.textContent = historiaFinal;
    caixaAlternativas.textContent = ""
    
}